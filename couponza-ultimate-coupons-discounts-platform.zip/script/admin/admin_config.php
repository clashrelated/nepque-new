<?php

$config = array(
	
    'images_folder' => '../../images/'
);

?>