/* ----------------------------------------------------------- */
/* COLOR VARIABLES */
/* ----------------------------------------------------------- */

body{
	--primary-color: {primary_color};
	--secondary-color: {secondary_color};
	--secondary-alpha-Dot50: {secondary_color_50};
	--secondary-alpha-Dot85: {secondary_color_85};
}