[
  {"title": "Welcome Email",
  "description": "HTML",
  "url": "../emails/email-welcome.html"
  },
  {"title": "Forgot Password - Reset Link",
  "description": "HTML",
  "url": "../emails/reset-password.html"
  },
  {"title": "Password Reset - Confirmation",
  "description": "HTML",
  "url": "../emails/confirmation-password.html"
  }
]